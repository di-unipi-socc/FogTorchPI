package di.unipi.socc.fogtorchpi.experiments;

import di.unipi.socc.fogtorchpi.utils.StdRandom;

public class Main {

    public static void main(String[] args) {
        for (int i = 0; i < 10; i++){
            System.out.println((int)StdRandom.gaussian(4,1));
            if ((int)StdRandom.gaussian(4,1) < 0){
                System.out.println("negative");
            }
        }
    }
}
