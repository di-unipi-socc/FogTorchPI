package di.unipi.socc.fogtorchpi.experiments;

import di.unipi.socc.fogtorchpi.application.Application;
import di.unipi.socc.fogtorchpi.application.ExactThing;
import di.unipi.socc.fogtorchpi.application.ThingRequirement;
import di.unipi.socc.fogtorchpi.deployment.Deployment;
import di.unipi.socc.fogtorchpi.deployment.MonteCarloSearch;
import di.unipi.socc.fogtorchpi.infrastructure.Infrastructure;
import di.unipi.socc.fogtorchpi.utils.Couple;
import di.unipi.socc.fogtorchpi.utils.Hardware;
import di.unipi.socc.fogtorchpi.utils.QoS;
import di.unipi.socc.fogtorchpi.utils.QoSProfile;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import static java.util.Arrays.asList;

/**
 * Created by Stefano on 21/10/2017.
 */
public class FTPiVRSimple {

    private static final int SMARTPHONES = 4; //always 4
    private static final int GATEWAYS = 16; // 1, 2, 4, 8, 16
    private static final int TIMES = 1000;

    public static void main(String[] args) {
        HashMap<Deployment, Couple<Double, Double>> histogram = new HashMap<>();

        Infrastructure I = new Infrastructure();
        Application A = new Application();

        I.addCloudDatacentre("cloud", asList(
                new Couple("linux", 0.0)),
                52.195097, 3.0364791,
                new Hardware(0, 0, 0, 3.0, 0.05, 0.01)
        );

        //Fog ISP proxy
        I.addFogNode("isp", asList(new Couple("linux", 0.0)),
                new Hardware(3, 4, 64, 3.0, 0.05, 0.01),
                43.740186, 10.364619);

        //link from isp-cloud
        I.addLink("cloud", "isp", new QoSProfile(50, 150, 5.0, 15.0));

        //Fog Gateways
        for (int i = 0; i < GATEWAYS; i++){
            I.addFogNode("gw_"+i, asList(new Couple("linux", 0.0)),
                    new Hardware(3, 4, 32, 3.0, 0.05, 0.01),
                    43.740186, 10.364619);

            //link isp-isp
            I.addLink("gw_"+i, "isp", new QoSProfile(1, 7, 5.0, 15.0));
            //link isp-cloud
            I.addLink("gw_"+i, "cloud", new QoSProfile(51, 157, 5.0, 15.0) );
            //link gw-gw
            if (i > 0){
                for (int k = 0; k < i; k++){
                    I.addLink("gw_"+i, "gw"+k, new QoSProfile(2, 14, 5.0, 15.0) );
                }
            }


            //Smartphones
            for (int j = 0; j < SMARTPHONES; j++){
                I.addFogNode("sp_"+i+"_"+j, asList(new Couple("linux", 0.0)),
                        new Hardware(2, 1, 16, 0.0, 0.00, 0.00),
                        43.740186, 10.364619);
                //link sp-isp
                I.addLink("sp_"+i+"_"+j, "gw_"+i, new QoSProfile(1, 3, 5.0, 15.0));
                //link sp-isp
                I.addLink("sp_"+i+"_"+j, "isp", new QoSProfile(2, 10, 5.0, 15.0));
                //link sp-cloud
                I.addLink("sp_"+i+"_"+j, "cloud", new QoSProfile(52, 160, 5.0, 15.0));

                I.addThing("EEG"+i+"_"+j, "EEG_sensor",0,0, "sp_"+i+"_"+j, 0.01);
                I.addThing("display"+i+"_"+j, "display",0,0, "sp_"+i+"_"+j, 0.01);
            }
        }


        System.out.println(I);

        A.addComponent("concentrator", asList("linux"), new Hardware(1,0.1, 5));
        A.addComponent("coordinator", asList("linux"), new Hardware(1,0.1, 10));

        A.addLink("concentrator", "coordinator", 200, 0,1);


        for (int i = 0; i < GATEWAYS; i++){
            for (int j = 0; j < SMARTPHONES; j++){
                String componentName = "client_"+i+"_"+j;
                ArrayList<ThingRequirement> neededThings = new ArrayList<>();
                // QoSProfile qNodeThing, QoSProfile qThingNode
                neededThings.add(new ExactThing("EEG"+i+"_"+j, new QoSProfile(6, 0), new QoSProfile(6, 0.5), 0));
                neededThings.add(new ExactThing("display"+i+"_"+j, new QoSProfile(1, 1), new QoSProfile(1, 0), 0));
                A.addComponent(componentName, asList("linux"), new Hardware(1,0.1, 1), neededThings);

                A.addLink("concentrator", "client_"+i+"_"+j, 50, 0.5, 1);
                A.addLink("coordinator", "client_"+i+"_"+j, 200, 0, 1);
            }
        }

        System.out.println(A);

        MonteCarloSearch s = new MonteCarloSearch(TIMES, A, I); //new Coordinates(43.740186, 10.364619));

       for (int i = 0; i < GATEWAYS; i++){
            for (int j = 0; j < SMARTPHONES; j++) {
                s.addBusinessPolicies("client_"+i+"_"+j, asList("sp_"+i+"_"+j));
            }
        }

        String filename
                = "C:\\Users\\Stefano\\Dropbox\\_Dottorato\\iFogSimFTPi\\comparison_";


        histogram = s.startSimulation(asList());
        String name = filename + ".csv";
        try {
            PrintWriter writer = new PrintWriter(name, "UTF-8");
            writer.println("Deployment ; QoS-assurance; Hardware %;Cost");
            System.out.println("Deployment ; QoS-assurance ; Hardware %;Cost");
            int j = 0;

            for (Deployment dep : histogram.keySet()) {
                writer.println(dep + "; " + histogram.get(dep).getA() + ";" + histogram.get(dep).getB() + "; " + dep.deploymentMonthlyCost);
                System.out.println(j + " - " + dep + "; " + histogram.get(dep).getA() + "; " + histogram.get(dep).getB() + "; " + dep.deploymentMonthlyCost);
                j++;
            }
            writer.close();
        } catch (IOException e) {
        }


        System.out.println("***Simulation is over.");

    }

}
